package bank;

public abstract class account {

	private String name;
	double money;
	//static double interest;
	public account(){
		name="No Name";
	}
	
	public account(String name, double money1){
		this.name=name;
		money=money1;
	}
	
	public void out(){
		System.out.println("Name: "+ name);
		System.out.println("Money: "+ money);
	}
	
	public void setName(String name1){
		name=name1;
	}
	
	public void setMoney(double money1){
		money=money1;
	}
	 public abstract String getDetails();
	 
	/*
	void increase(){
		money += money*getInterest();
	}*/
	 
	void deposit(double x){
		money += x;
	}
	void withdraw(double x){
		money -= x;
	}
	public String getName(){
		 return name;
	 }
}

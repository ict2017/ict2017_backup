package bank;

import java.util.Scanner;

public class bank1 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);	

		SavingAccount acc1;
		acc1 = new SavingAccount();
		/*
		System.out.print("Input money: ");
		acc1.money = in.nextInt();
		in.nextLine();
		System.out.print("Input name: ");
		acc1.name = in.nextLine();
		System.out.print("Input interest: ");
		acc1.interest = in.nextDouble();
		in.nextLine();*/
                acc1.setName("Me");
                acc1.setMoney(15000);
		System.out.println("Name: " + acc1.getName());
		//acc1.increase();
		
		System.out.println("Money: " + acc1.money);
		System.out.print("Input interest: ");
                acc1.setInterest(in.nextDouble());
                System.out.println("Interest: " + acc1.getInterest());
		acc1.receive(20000);
		if(in != null) {
		    in.close();
		}
	}
}
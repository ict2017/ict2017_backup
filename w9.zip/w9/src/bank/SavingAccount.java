package bank;



public class SavingAccount extends account{
	private String dateCreated;
	private String todayDate;
    private double interest;
    
    public void withdraw(double x){
    	if(todayDate.equals(dateCreated))
    		money -= x;
    }
    @Override
    public void deposit(double x){
    	if(todayDate.equals(dateCreated))
    		money += x;   	
    }
    public void setInterest(double in){
        interest = in;
    }
    public double getInterest(){
        return interest;
    }
    public void updateBalance(){
        money += money*getInterest();
        System.out.println("New Balance = " + money); 
   }
	@Override
	public String getDetails() {
		// TODO Auto-generated method stub
		return null;
	}
}

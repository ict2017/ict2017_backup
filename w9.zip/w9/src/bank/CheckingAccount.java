package bank;

import java.util.Scanner;

public class CheckingAccount extends account{

	private String name;
	double money;

	public String getDetails() {

		return name;
	}

	}
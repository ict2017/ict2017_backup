#include <stdio.h>
int main()
{
	char c;

	while (c!='0')
		{scanf("%c",&c);
	{
	if (c!='\n')
	printf("%d\n",c);
	}} ;
}
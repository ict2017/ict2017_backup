#include <stdio.h>
#define size 10
int main(){
	int A[10]={1,5,3,6,8,9,4,2,0,7};
	int i,j,n;
	srand((unsigned)time(NULL));
	for(i=0;i<size;i++) A[i]=rand()%10+1;
	
	for(i=0;i<size;i++){
		for(j=i;j<size;j++){
			if(A[i]<A[j]){
				n=A[i];
				A[i]=A[j];
				A[j]=n;
			}
		}
	}
	for(i=0;i<10;i++) printf("%d   ",A[i]);
}
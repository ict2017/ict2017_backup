#include <stdio.h>
#include <math.h>

int main()
{
	float a,b,c,d,x,y;
	int m,n;
	printf("GPT ax^2+bx+c=0.\nNhap a,b,c:\n");
	scanf("%f%f%f",&a,&b,&c);
	
	d=b*b-4*a*c;
	
	if (d<0) printf("phuong trinh vo nghiem\n");
	else 
	{
	if (d==0) 
	{
	printf("phuong trinh co 1 nghiem duy nhat x=%f/%f", -b,(2*a));
	
	m=-b;
	n=2*a;
		while(m%2==0 && n%2==0)
		{
		m=m/2;
		n=n/2;
		};
	
	while(m%3==0 && n%3==0)
		{
		m=m/3;
		n=n/3;
		};

	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	
	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	printf("=%d/%d\n",m,n);
	}
	
	
	else 
	{
	printf("phuong trinh co 2 nghiem phan biet\n x1=%f\nx2=%f\n",(-b+sqrt(d))/(2*a),(-b-sqrt(d))/(2*a));
	m=-b+sqrt(d);
	n=2*a;
		while(m%2==0 && n%2==0)
		{
		m=m/2;
		n=n/2;
		};
	
	while(m%3==0 && n%3==0)
		{
		m=m/3;
		n=n/3;
		};

	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	
	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	printf("x1 ~ %d/%d\n",m,n)	;
	
	m=-b-sqrt(d);
	n=2*a;
		while(m%2==0 && n%2==0)
		{
		m=m/2;
		n=n/2;
		};
	
	while(m%3==0 && n%3==0)
		{
		m=m/3;
		n=n/3;
		};

	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	
	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	printf("x2 ~ %d/%d\n",m,n)	;
	
	}	
	}	
	return(0);
}
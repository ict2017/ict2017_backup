/**********************************************************
 * BASE-n SYSTEM CONVERTER PROGRAM                        *
 * AUthor: HaoNV             ID:20111494                  *
 * Class: ICT                                             *
 * Created as C Programming Language Exercises 2          *
 **********************************************************/

#include <stdio.h>

void dectoany(int a,int h);
int anytodec(int a,int h);

int main() {
	int n,m,hecoso1, hecoso2;

//input	
	printf("============BASE-n SYSTEM CONVERTER=============\n\n");
	printf(" INPUT number-----------------------------------\n");
	do{
		printf("  Base of number need to convert (2,8,10,16): "); //16 chua xong, dang hoan thien
		scanf("%d",&hecoso1);
	} while (hecoso1!=2 && hecoso1!=8 && hecoso1!=10 && hecoso1!=16);
	
	
	printf("  Number need to convert: ");
	scanf("%d",&n);
	
	
		printf("\n OUTPUT number----------------------------------\n");
	do{
		printf("  Base of output number: ");
		scanf("%d",&hecoso2);
	} while (hecoso2!=2 && hecoso2!=8 && hecoso2!=10 && hecoso2!=16);
	
//now convert inputed number to decimal	
	m=n;
	n=anytodec(n,hecoso1);

//print output	
	printf("\n\n RESULT:_______________________\n|                              |\n");
	printf("|  %d (%d) = ",m,hecoso1); dectoany(n,hecoso2);
	printf(" (%d)\n|______________________________|\n",hecoso2);
	return(0);
}

void dectoany(int a,int h) {
	int A[100], dem=0,i=0;
	do{
		A[i]=a%h;
		a/=h;
		dem++;
		i++;
	} while(a>0);
	
	for(i=dem-1;i>=0;i--){
		switch(A[i]){
			case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 0: printf("%d",A[i]); break;
			case 10: printf("A"); break;
			case 11: printf("B"); break;
			case 12: printf("C"); break;
			case 13: printf("D"); break;
			case 14: printf("E"); break;
			case 15: printf("F"); break;
		}
	}
}

int anytodec(int a,int h){
	int dec=0,hh=1;
	do{
		dec+=(a%10)*hh;
		hh*=h;
		a/=10;
	} while (a>0);
	return (dec);
}
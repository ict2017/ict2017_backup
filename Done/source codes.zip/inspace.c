#include <stdio.h>

int main(){
  char c,i;
  while( (c=getchar()) !=-1){
    if( c==' '){
      if (i==0) {
      i=1; 
      putchar(c);
    }
    }
  if( c!=' '){
    i=0;
    putchar(c);}
  }
}
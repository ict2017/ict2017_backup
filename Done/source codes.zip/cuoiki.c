#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<time.h>
#include <stdlib.h>


void sapxep(int a[], int n)   //sap sep mang tang
{	
	int tam,i,j;
	for(i=0;i<n;i++)
	{	for(j=i+1;j<n;j++)
		{	if(a[i]>a[j])//dieu kien sai
			{
				tam=a[i];
				a[i]=a[j];
				a[j]=tam;
			}
		}
	}
}



//------------------------------------------------------------------------------
int kiem_tra(int ngay, int thang, int nam) {
	if(ngay<1||ngay>31||thang<1||thang>12) return 0;
	else {
		if(thang==4||thang==6||thang==9||thang==11)	{ //thang ko co ngay 31
			if(ngay==31)return 0;
			else return 1;
		}
		else if(thang==2) {
			if(ngay>29) return 0;	//thang 2 co nhieu nhat la 29 ngay
			else if(ngay==29){
				if(nam_nhuan(nam)==1) return 1;
				else return 0;
			}
			else return 1;
			}
		else return 1;
	}
}
//------------------------------------------------------------------------------
int nam_nhuan(int nam) {
	
	if(nam%400==0) return 1;
	else {
		if(nam%100==0) return 0;
		else {
			if(nam%4==0) return 1;
			else return 0;
		}
	}
}
//------------------------------------------------------------------------------
int main()
{
        int choose;
        int i,j;
        do{
        	clear();
                printf("__MENU__\n");
                printf("1.  \n");
                printf("2.   \n");
                printf("3.    \n");
                printf("4.     \n");
                printf("0.Exit     \n");
                printf("Your Choose: ");
                scanf("%d", &choose);
                switch(choose)
                        {
                                case 1:
                                printf("     \n");
                                
                                case 2:
                                printf("     \n");
                                case 3:
                                printf("     \n");
                                case 4:
                                printf("     \n");
                                case 0: break;
                        }
                } while( choose!=0);       
}
//______________________________________________________________________________

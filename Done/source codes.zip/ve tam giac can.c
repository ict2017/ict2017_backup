#include <stdio.h>
int main(){
	int h,a,b,i,j,k;
	
	do {printf("In tam giac can rong giua co chieu cao h.\nNhap chieu cao h: ");scanf("%d",&h);} while (h<=0);
	for (i=1;i<h;i++)
	{
		for (j=1;j<2*h;j++)
		{	
			if(j==(h-i+1)|| j==(h+i-1))
				printf("*");
			else printf(" ");
		}
			printf("\n");
	}
	for(k=1;k<h;k++) printf("* ");
	
	printf("*\n\n\n\n");
	
	do {printf("In tam giac can dac co chieu cao h.\nNhap chieu cao h: ");scanf("%d",&h);} while (h<=0);
	for (i=1;i<=h;i++)
	{
		for (j=1;j<2*h;j++)
		{	
			if(j<(h-i+1)|| j>(h+i-1))
				printf(" ");
			else printf("*");
		}
		printf("\n");
	}
	printf("\n\n\n");
	return(0);				
}
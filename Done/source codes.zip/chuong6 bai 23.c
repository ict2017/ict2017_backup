#include <stdio.h>
int main()
{
	
	int a,b,c,d;
	for(a=1;a<=9;a++)
		for(b=1;b<=9;b++)
			for(c=1;c<=9;c++)
				for(d=1;d<=9;d++)
					if (a*d*d==b*c*c*c)
					printf("a=%d\tb=%d\tc=%d\td=%d\n",a,b,c,d);
}
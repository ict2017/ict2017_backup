#include <stdio.h>

int main(){
	int i;
	for(i=0;i<=31;i++)	printf("%d = %c\n",i,i);
	printf("Special Characters: (32-47)\n");
	for(i=32;i<=47;i++)	printf("%d = %c\n",i,i);
	printf("Numbers: \n");
	for(i=48;i<=57;i++)	printf("%d = %c\n",i,i);
	printf("Upper Characters:\n");
	for(i=65;i<=90;i++)	printf("%d = %c\n",i,i);
	printf("Lower Characters:\n");
	for(i=97;i<=122;i++)	printf("%d = %c\n",i,i);
}
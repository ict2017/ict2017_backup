#include <stdio.h>
int main()
{
	int k,n,i;
	float c=1.00;
	printf("***\tTinh to hop chap N cua K (K<=N)\t ***\n");
	do
	{
		printf("Nhap N: ");scanf("%d",&n);
		printf("Nhap K: ");scanf("%d",&k);
	}
	while (k<0 || k>n);
	
	for(i=1;i<=k;i++)
	{
		c=c*(((float)n-(float)k+(float)i)/(float)i);
	}
	printf("%f\n",c);
}
/*********************************
 * Author: HaoNV                 *
 * Exercises 1- Week 14          *
 * The C Programming Language    *
 * (c) Copy if you want          *
 *********************************/


#include <stdio.h>
#define somay 8
typedef struct times {
  int hour;
  int minute;
} timet;

typedef struct com_type {
  int number;
  int free;
  timet begintime;
  timet endtime;
  long fee;
  int timeused;
}computer;

computer A[somay+1];

int getmenu();
void inphongmay();
int khoitao();
int timevaild(timet a);
int dungmay();
int timecompare(timet a, timet b);
int nghingoi();
int tinhtien(timet a, timet b);
int intien();
int chuyenmay();
int goiy();

int main(){
  int menu;  

  do {
    menu=getmenu();
    switch(menu){
    case 1: khoitao(); break;
    case 2: dungmay(); break;
    case 3: nghingoi();break;
    case 4: chuyenmay(); break;
    case 5: inphongmay(); break;
    case 6: intien(); break;
    case 7: goiy(); break;
    }
  } while (menu!=8);
}







//functions

int getmenu(){
  int menu;

  do{ 
    printf("\n1. Khoi tao du lieu\n");
    printf("2. Dung may\n");
    printf("3. Nghi ngoi\n");
    printf("4. Chuyen may\n");
    printf("5. In ra trang thai phong may\n");
    printf("6. In ra thong tin phong may\n");
    printf("7. Goi y dung may\n");
    printf("8. Thoat\n");
    printf("Lua chon cua ban: \t" );
    scanf("%d",&menu);
  }  while(menu<0|| menu>8);
  printf("\n");
    return menu;
}

void inphongmay(){
  int i;

  printf("STT\tstatus\tbegin\tend\tfee\ttimeused\n");
  for(i=1;i<(somay+1);i++){
printf("%d\t%d\t%d:%d\t%d:%d\t%d\t%d\n",A[i].number,A[i].free,A[i].begintime.hour,A[i].begintime.minute,A[i].endtime.hour,A[i].endtime.minute,A[i].fee,A[i].timeused);
  }
  printf("\n");
}

int khoitao(){
  int i;
  printf("-----KHOI TAO DU LIEU--------\n");
  for(i=1;i<(somay+1);i++){
    (A+i)->number=i;
    (A+i)->free=1;
    (A+i)->begintime.hour=0;
    (A+i)->begintime.minute=0;
    (A+i)->endtime.hour=0;
    (A+i)->endtime.minute=0;
    (A+i)->timeused=0;
  }
  inphongmay();
}

int timevaild(timet a){
  int ok;
  if(a.hour>=0 && a.hour<24){
    if (a.minute >=0 && a.minute<60){
      return 1;
    } else return 0;
  } else return 0;
} 

int dungmay(){
  int so,i,trangthai;
  for(i=1;i<(somay+1);i++)
    if(A[i].free==0) trangthai++;
  if(trangthai==8) printf("Tat ca cac may da duoc dung, xin moi quay lai sau\n\n");
  else{
    do{
      printf("Nhap so may can dung: ");
      scanf("%d",&so);
    }while (so< 1 || so >8);
   
    for(i=1;i<(somay+1);i++){
      if(so==A[i].number){
	if(A[i].free==1){
      do{
        printf("Nhap thoi gian bat dau: ");
        scanf("%d%*c%d",&(A+i)->begintime.hour, &(A+i)->begintime.minute);
      }while(timevaild(A[i].begintime)==0);
      
	  (A+i)->free=0;
	  printf("OK! Xin moi dung may\n\n");
	} else printf("May da co nguoi dung, xin chon may khac\n\n");
      } 
    }
  }
}

int timecompare(timet a, timet b){
  if(a.hour<b.hour) return -1;
  else if(a.hour==b.hour){
    if(a.minute<b.minute) return -1;
    else if(a.minute==b.minute) return 0;
    else return 1;
  }
  else return 1;
}


int nghingoi(){
  int i,so,sophut,tien;
  do{
    printf("Nhap may muon thanh toan: ");
    scanf("%d",&so);
  }while(so<=0 || so>8);
  
  for(i=1;i<somay-1;i++){
    if(A[i].number==so){
      if(A[i].free==0){
	do{
	  printf("Nhap thoi gian ket thuc: ");
	  scanf("%d%*c%d",&(A+i)->endtime.hour,&(A+i)->endtime.minute);
	} while (timecompare(A[i].endtime, A[i].begintime)==-1);
	printf("\nHOA DON THANH TOAN\n");
	printf("Thoi gian bat dau : \t%d:%d\n",A[i].begintime.hour,A[i].begintime.minute);
	printf("Thoi gian ket thuc: \t%d:%d\n",A[i].endtime.hour,A[i].endtime.minute);
	(A+i)->timeused+= tinhtien(A[i].endtime,A[i].begintime);
	(A+i)->fee+= A[i].timeused*100;
	(A+i)->free=1;
      } else printf("May chua duoc dung, nhap lai so may\n");
    }
  }
}


int tinhtien(timet a, timet b){
  int sophut,tien;
  sophut=a.hour*60+a.minute - b.hour*60-b.minute;
  tien=sophut*100;
  printf("So phut dung dich vu: %d\n",sophut);
  printf("So tien can tra: %d\n",tien);
  return sophut;
}


int intien(){
  computer B[somay+1],M;
  int i,j;
  for(i=1;i<somay+1;i++) B[i]=A[i];

  for(i=1;i<somay+1;i++){
    for(j=i;j<somay+1;j++){
      if(B[i].fee < B[j].fee){
        M=B[i];
        B[i]=B[j];
        B[j]=M;
      }
    }
  }
  printf("STT\tstatus\tbegin\tend\tfee\ttimeused\n");
  for(i=1;i<(somay+1);i++){
printf("%d\t%d\t%d:%d\t%d:%d\t%d\t%d\n",B[i].number,B[i].free,B[i].begintime.hour,B[i].begintime.minute,B[i].endtime.hour,B[i].endtime.minute,B[i].fee,B[i].timeused);
  }
  printf("\n");

}


int chuyenmay(){
  int maymuonchuyen, maycanchuyen,i,j;
  do{
    printf("NHap may can chuyen: ");
    scanf("%d",&maycanchuyen);
  }while(maycanchuyen<1||maycanchuyen>somay);


  for(i=1;i<somay+1;i++){
    if(maycanchuyen==A[i].number){
      if(A[i].free==0){

        do{
          printf("Nhap may muon chuyen toi: ");
          scanf("%d",&maymuonchuyen);
        }while(maymuonchuyen<1||maymuonchuyen>somay);
        
        for(j=1;j<somay+1;j++){
          if(maymuonchuyen==A[j].number){
            if(A[j].free==1){
              A[j].begintime=A[i].begintime;
              A[i].begintime.hour=0;A[i].begintime.minute=0;
              A[i].free=1;
              A[j].free=0;
            }else printf("May muon chuyen toi dang ban, nhap lai\n");
          }
        }
      }else printf("May can chuyen chua duoc su dung, nhap lai\n");
    }
  }
}


int goiy(){
  int maygoiy=A[1].number, min=A[1].timeused, i,j,count=0;
  for(i=somay;i>0;i--){
    if(A[i].free==0) count++;

    else{
      if(A[i].free==1 && A[i].timeused<=min){
        min=A[i].timeused;
        maygoiy=A[i].number;
      }
    }
  }
  if(count==8) printf("Tat ca cac may da su dung, vui long quay lai sau\n");
  else printf("Ban nen su dung may %d\n",maygoiy);
}

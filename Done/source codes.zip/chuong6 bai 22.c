#include <stdio.h>
int main()
{
	
	int a,b,c,d;
	for(a=1;a<=9;a++)
		for(b=1;b<=9;b++)
			for(c=1;c<=9;c++)
				if (a+b+c==a*b*c)
				printf("%d%d%d\n",a,b,c);
}
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

//================ procedure functions ====================//
int getmenu(int *menu){
printf("\n=====================\n");
printf(" SELECT AN OPTION\n\n");
printf("1. Nhap so\n");
printf("0. Quit\n");
printf("\n Your choice is: ");
scanf("%d", menu);
return *menu;
}

//function that returns whether a prime
int is_prime(long n){
long i;
if (n<2) return 0;
for (i=2;i<= sqrt(n);i++ )

if (n%i==0) return 0;
return 1;
}

//=================== main program =========================//
int main(int argc, char const *argv[])
{
int menu;
int k, dem;
double n, tich;
float can, temp;
long min, max, temp2;
while ( getmenu(&menu) ){
printf("nhap N va K: ");
scanf("%lf %d", &n, &k);
can = (float)1 / (float)k;
temp = pow(n, can);
printf("so can: %.1lf -> %f\n", n, temp);
temp2 = (long) temp;
dem = 0; tich = 1;
do {
if (is_prime(temp2))
{
tich *= temp2;
dem++;
printf("%ld %d\n", temp2, dem);
}
temp2--;
if (temp2<2) break;
} while (dem <= ceil(k/2));
min = temp2+1;

temp2 = (long) temp +1;
do {
if (is_prime(temp2))
{
tich *= temp2;
dem++;
printf("%ld %d\n", temp2, dem);
}
temp2++;
} while (dem <= k);
max = temp2-1;

printf("%.1lf\nTich: %.1lf\n Ket qua la 1 trong 2 so sau:\n%.1lf\n%.1lf\n", n, tich, tich/min, tich/max);
printf("Vay ket qua la: %.1lf\n", tich/max <= n? tich/max: tich/min<= n? tich/min : -1);
}
printf("Good bye!!!\n");
return 0;
}
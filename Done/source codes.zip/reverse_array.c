#include <stdio.h>

int reverse_passing_value(int [], int);
int reverse_passing_reference(int*,int);

int main(){
	int A[100]={1,3,4,11,5,6,8},size=7,i,j;
	
	//reverse_passing_value(A,size);
	reverse_passing_reference(A,size);
	for(i=0;i<size;i++){
		printf("%d   ",A[i]);
	}
}

int reverse_passing_value(int a[],int size){
	int i,j,temp;
	for (i=0;i<((size)/2);i++){
		temp=a[i];
		a[i]=a[size-1 -i];
		a[size-1-i]=temp;
	}
	return;
}

int reverse_passing_reference(int *p,int size){
	int i,temp;
	for (i=0;i<((size)/2);i++){
		temp=*(p+i);
		*(p+i)=*(p+size-1-i);
		*(p+size-1-i)=temp;
	}
}
#include <stdio.h>

void dectoany(int a,int h);

int main() {
	int n,hecoso;
	printf("Nhap so can chuyen: ");
	scanf("%d",&n);
	printf("Nhap he co so can chuyen sang: ");
	scanf("%d",&hecoso);
	dectoany(n,hecoso);
	
	return(0);
}

void dectoany(int a,int h) {
	int A[100], dem=0,i=0;
	do{
		A[i]=a%h;
		a/=h;
		dem++;
		i++;
	} while(a>0);
	
	for(i=dem-1;i>=0;i--){
		switch(A[i]){
			case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 0: printf("%d",A[i]); break;
			case 10: printf("A"); break;
			case 11: printf("B"); break;
			case 12: printf("C"); break;
			case 13: printf("D"); break;
			case 14: printf("E"); break;
			case 15: printf("F"); break;
		}
	}
	printf("\n");
}
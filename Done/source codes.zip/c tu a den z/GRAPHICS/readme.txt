De co the su dung mouse, ta co the dung hai cach :
1- Dung Project de tao chuong trinh. Trong Project co 
   chuong trinh cua minh va EVENT.OBJ
2- Dung tlib de them EVENT.OBJ vao GRAPHICS.LIB.

Chu y :
Neu dang thuc tap trong phong may thi cach thu nhat tien hon.
Neu dang thuc tap o nha thi cach thu hai tien hon.

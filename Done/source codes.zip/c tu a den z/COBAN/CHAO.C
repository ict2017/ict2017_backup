/* Bai tap 2_2 - Nhap chuoi va in chuoi */
#include <stdio.h>

void main()
{
   char name[80];

   printf("\nXin cho biet ten cua ban : ");
   gets(name);

   printf("Chao %s\n", name);
   getch();
}
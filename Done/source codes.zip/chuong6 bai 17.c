#include<stdio.h>
int main()
{
int a,i,n;
scanf("%d", &a); for(i=2;i<=a;) 
if(a%i==0)
{
	printf("%d*", i);
	a/=i;
}
else i++; }
#include <stdio.h>
#include <string.h>

int replace(char *a,char *b, char *c){
	int i,j,k;
	char a1[100],b1[100],c1[100],temp[100];
	
	for(i=0;i<strlen(a);i++){
		for(j=i;j<strlen(a);j++){
			for(k=0;k<=j-i+1;k++){
				temp[k]=a[i+k];
				temp[j+1-i]=NULL;
			}
			
			if (strcmp(temp,b)==1){
				strcpy(a1,a);
				*(a1+i)=NULL;
				
				strcpy(c1,a+j+1);
				*(c1+strlen(a)-j-1)=NULL;
			}
		}
	}
	
	strcat(c,c1);
	strcat(a1,c);
}

int main(){
	char a[100],b[100],c[100];
	gets(a);
	replace(a,'ac','000');
	printf("--%s--",a);
}
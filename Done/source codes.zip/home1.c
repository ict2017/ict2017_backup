#include <stdio.h>
#define RED "\x1b[31m"
#define BOLD "\x1b[1m"
#define ITALIC "\x1b[4m"
#define MARK "\x1b[7m"
#define WHITE "\x1b[8m"
#define STRIKE "\x1b[9m"
#define GREEN   "\x1b[32m"
#define YELLOW  "\x1b[33m"
#define BLUE    "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN    "\x1b[36m"
#define RESET "\x1b[0m"

int main()
{
  char university[50], name[30], grade[10], sex[10], location[50], class[10], id[10];
  int x, d,m,y;

  printf("Your college: "); gets(university);
  printf("Your name: "); gets(name);
  printf("Your id: "); scanf("%s[0-9]", id);
  printf("Your birthday: "); scanf("%2d%*c%2d%*c%4d", &d, &m, &y);
  printf("Your gender: "); scanf ("%s", sex);
  printf("Where were you born ?"); scanf(" %[a-zA-Z- ]s", location);
  printf("Your class: "); scanf("%s[A-Z]", class);
  printf("Your grade: "); scanf("%s", grade);


  printf("\t" ITALIC "%52s", " " RESET "\n");
  printf("\t| ***" "%11s", " ");
  printf(BOLD BLUE "DAI HOC BACH KHOA HA NOI" RESET);
  printf("%9s", " " "|\n");
  printf("\t| ***" "%17s", " ");
  printf(BOLD RED "THE SINH VIEN" RESET);
  printf("%14s", " " "|\n");
  printf("\t|" "%48s", " " "|\n");
  printf("\t|"); x= printf("********* MSSV: ");
  scanf("name: ", &id); printf("%-30s", id); printf("|\n");
  printf("\t|"); x= printf("********* Ho ten: ");
  scanf("name: ", &name); printf("%-28s", name); printf("|\n");
  printf("\t|"); x= printf("********* Ngay sinh: %2d/%2d/%4d", d,m,y);
  printf("%7s", " ");
  printf("%7s", sex); printf(" |\n");
  printf("\t|"); x= printf("********* Ho khau tt: ");
  scanf("name: ", &location); printf("%-24s", location); printf("|\n");
  printf("\t|"); x= printf("********* lop: ");
  scanf("name: ", &class); printf("%-31s", class); printf("|\n");
  printf("\t|"); x= printf("********* Khoa hoc: ");
  scanf("name: ", &grade); printf("%-15s", grade); 
  printf("%-16s", "30/05/2016 |\n");
  printf("\t|                            |||||||||||||||   |\n");
  printf("\t|NPH:15/11/2011              |||||||||||||||   |\n");
  printf("\t|" ITALIC "%52s", " " RESET "|\n");
  return 0;
}

/**********************************************************
 *  Homework Exercise 1                                   *
 *  Author: HaoNV                                         *
 *  Created as exercise of C Programming Language Course  *
 *  In this exercise, write a program that make a student *
 *  card by using information are entered from user       *
 **********************************************************/

#include <stdio.h>
#include <string.h>

//define some color
#define RED "\x1b[31m"
#define BOLD "\x1b[1m"
#define ITALIC "\x1b[4m"
#define MARK "\x1b[7m"
#define WHITE "\x1b[8m"
#define STRIKE "\x1b[9m"
#define GREEN   "\x1b[32m"
#define YELLOW  "\x1b[33m"
#define BLUE    "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN    "\x1b[36m"
#define RESET   "\x1b[0m"
#define BAR_CODE "||\xE2\x96\x88|\xE2\x96\x88\xE2\x96\x88|||\xE2\x96\x88|\xE2\x96\x88\xE2\x96\x88"  //use utf-8 character "fullbox"


void func(char *, int);
void trans(char *);
/*this functions will transform all characters (upper and lower) of string
  into upper strings then print them and print "space" in order to make
  your card is rectangular. Note that your card has length is '45'*/
 
void func(char *s, int m){
  int i;
  for (i=1; i<=45; i++)
    if (i>(m+strlen(s)))
      printf(" ");
  printf("|\n");
}

void trans(char *s){
  int j;
  for(j=0; j<=strlen(s); j++)
    if(s[j]>=97 && s[j]<122)
      s[j]-=32;
  printf("%s",s);
}

int main(){
  char university[50], name[30], location[50], stclass[10], id[10];
  int i,y, dd,mm,yyyy, grade,z,sex;
    
//start input data   
  printf("This program will make your student card by using your information.\n");
  //  printf("Your college: "); gets(university);
  printf("Your name: "); gets(name);
  printf("Your ID: "); scanf("%s[0-9]",&id);
  printf("Your Birthday: "); scanf("%d%*c%d%*c%d",&dd,&mm,&yyyy);
  do{
    printf("Gender: (1=male\t2=female\t3=gay\t4=less)\t"); scanf("%d",&sex);}
  while( sex<=0 || sex>=5);
  printf("Where was you born? "); scanf(" %[a-zA-Z- ]s",location);
  printf("Your class: "); scanf(" %s",stclass);
  printf("Your grade: "); scanf(" %*c%d",&grade);
//end of input data

  
//now apply function and print output
 printf(RESET "\n\n\n\t______________________________________________\n");
 printf("\t| ***        "BOLD BLUE"DAI HOC BACH KHOA HA NOI"RESET"        |\n");
 printf("\t| ***             "BOLD RED"THE SINH VIEN"RESET"              |\n");
 printf("\t|                                            |\n");
 printf("\t");y = printf("|********* MSSV: "); trans(id); func(id,y);
 printf("\t");y = printf("|********* Ho ten: ");trans(name); func(name, y);
 printf("\t|********* Ngay sinh: %d/%d/%d",dd,mm,yyyy);
 if(sex==1) printf("\t Nam |\n");
   else if(sex==2) printf("\t  Nu |\n");
   else if(sex==3) printf("\t Gay |\n");
   else printf("\tLess |\n");
 printf("\t");y = printf("|********* Ho khau TT: ");printf("%s",location); func(location,y);
 printf("\t");y = printf("|********* Lop: "); trans(stclass); func(stclass,y);
 printf("\t|********* Khoa hoc: K%d          30/5/2016  |\n",grade);
 printf("\t|                             "BAR_CODE"  |\n");
 printf("\t|NPH:15/11/2011               "BAR_CODE"  |\n");
 printf("\t|____________________________________________|\n\n\n\n");
return(0);
}

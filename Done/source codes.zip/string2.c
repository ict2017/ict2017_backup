#include <stdio.h>
#include <string.h>
#define MAX 1000
compare(char *p,char *q, int m){
	int i;
	for (i =0;i<m;i++)
		if ( *(p+i) != *(q+i))
			return(0);
	return(1);
}
changesub(char a[],char b[],char c[]){
// Searching in string a find b and replaced by c
	int n = strlen(a);
	int m = strlen(b);
	int i = 0,j, t = 0;
	char x[MAX];
	while (i < n){
		if ( i+m-1 < n)
		if ( compare(&a[i],&b[0],m) )
			{
				i = i+m;
				x[t] = NULL;
				strcat(x,c);
				t = strlen(x);
				continue;
			}
		x[t] = a[i];
		i++;
		t++;
	}
	x[t]= '\0';
	strcpy(a,x);
}
main(){
	char a[MAX];
	gets(a);
	changesub(a,"ac","OOO")	;
	printf("%s",a);
}
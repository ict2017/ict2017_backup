
/* Program   : Integrated Excercises - AllInOne  **
** Programmer: Nguyen Duc Hieu - Jeremy Newton   **
** Class     : ICT K56                           **
** Copyright - Alright reserved                  */

#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include <unistd.h>
//#include "math.h"

#define PI 3.1416f

//================ procedure functions ====================//
int getmenu(int *menu){
	printf("\n=====================\n");
	printf("  SELECT AN OPTION\n\n");
	printf("1. \n");
	printf("0. Quit\n");
	printf("\n Your choice is: ");
	scanf("%d", menu);
	return *menu;
}

//function clear enter in buffer like fflush(stdin)
void clear_buffer(){
  int ch;
  while ((ch=getchar()) != '\n' && ch!= EOF);
}

//function gets an positive integer number from user's input.
//if not satisfied, report error and input again.
void newscan(int *n, int min, int max){
  float temp;
  do{
    scanf("%f", &temp);
    if ( (temp - (int)temp != 0) || temp<min || temp>max){
      printf("- Input wrong! Please try again!\n");
      continue;
    }
    break;
  }while (1);
  *n = temp;
}

//function that checks a integer number whether a perfectnumber
int is_perfect(int n){
	int i, divisorsum;
	//because the first perfect number is 6, and all p_num is even
	if (n<6) return 0;
	else {
		divisorsum=0;
		for (i=1; i<=(n/2); i++){
			if (n%i==0) divisorsum += i;
		}
		if (divisorsum == n) return 1;
	}
	return 0;
}

//function that return absolute valute of float number
float absn(float p){
  if (p<0) p=-p;
  return p;
}

//function that returns square root of float number
//require user input 2 parameter: float number m, and precision epsilon
float sqroot(float m){
  float n1,n2;
  n1=n2=10;
  do{
    n1=n2;
    n2 = (n1*n1 + m)/(2*n1);
  }while (absn(n2-n1) > 0.00001);
  return n2;
}

//function that returns whether a prime
int is_prime(int n){
  int i;
  for (i=3; i<=sqroot(n); i+=2){
    if (n%i==0) return 0;
  }
  return 1;
}

//2 funtion that convert temperature from C to F and vice versa
float convertC2F(float tempC){
	return (1.8*tempC+32.0);
}
float convertF2C(float tempF){
	return ((tempF-32.0)/1.8);
}

//function convert degree to radian
float convertD2R(float degree){
	return (degree*PI/180);
}

//function returns the factorial of a integer number
long factorial(int n){
	int i;
	for (i = n-1; i > 0; --i) n *= i;
	return n;
}

//function returns power integer degree of a real number
float powern(float x, int n){
	if (n==0) return 1.0;
	int i;
	float result=1;
	for (i = 1; i <= n; ++i) result *= x;
	return result;
}

//get modulus between 2 float number
float modulus (float a, float b){
  int result;
  result = a/b;
  return a-b*result;
}

//return the round value of float number in range of point
float lamtron(float n, float point){
	float remain, modulus;
	int result;
	remain = n-(int)n;
	result = remain/point;
  	modulus = remain-result*point;
  	if (modulus<point/2) remain -= modulus;
  		else remain = remain - modulus + point;
  	return ( (int)n + remain );
}

//function returns value of sin(x) - x in radian by Taylor series
float sine(float x){
  float y = modulus(x, 2*PI);
  if (y>PI) y -= 2*PI;
  if (y< (-PI))y += 2*PI;

  float sine=0, temp;
  int i=0;
  do
    {
      temp = sine;
      sine += powern(-1, i) * powern(y, 2*i+1) / factorial(2*i+1);
      i++;
    } while (absn(sine - temp) > 0.00001);
  return sine;
}

//function that return a random integer number from a to b
int randint (int a, int b){
	int temp;
	if (a>b) {
		temp = a;
		a = b;
		b = temp;
	}
	srand(time(NULL));
	temp = b - a + 1;
	return (a + rand() % temp);
}

void qsort(int *A,int left,int right){
  int i,j,x,y;
  i=left;
  j=right;
  x=A[(left+right)/2];
  while(i<=j){
    while(A[i]<x&&i<right)i++; //check elements on the right whether they < x
    while(A[j]>x&&j>left)j--; //check elements on the left whether they > x
    // if not, swap A[i] and A[j]
    y=A[i];
    A[i]=A[j];
    A[j]=y;
    //then continue checking
    i++;
    j--;
  }
  //finish a turn, then sort the others
  if(left<j)qsort(A,left,j); //sort all left elements
  if(i<right)qsort(A,i,right);//sort all right elements
}

void baseconvert(long int n, int k){
  int b[16]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
  char a[100],i,j;
  i = 0;
  while (n > 0)
    {
      i++;
      a[i] = n % k;
      n = n/k;
    };
  for (j=i;j>=1;j--)
    printf("%c",b[a[j]]);
  printf("\n");
}

//=============== subprograms for main program =============//



//=================== main program =========================//
int main(int argc, char const *argv[])
{
	int menu;
	while ( getmenu(&menu) ){
		switch (menu){
			case 1: break;
		}
	}
	printf("Good bye!!!\n");
  sleep(5);

	return 0;
}
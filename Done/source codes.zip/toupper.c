#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main(){
	char s[100];
	int a,b;
	scanf("%[A-Za-z0-9 ]s",s);
	s[3] = toupper(s[3]);
	printf("%s\n",s);
	int i;
	scanf("%*c%d%d",&a,&b);
	for(i=a;i<=b;i++){
		s[i] = tolower(s[i]);
	}
	printf("%s\n",s);
}

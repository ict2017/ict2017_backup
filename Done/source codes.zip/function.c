#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void clrbuffer(){
   int ch;
   while((ch=getchar()) != '\n' && ch != EOF);
}


////////Function here/////////////////
//Creat Menu
/*
int getmenu(){
  int menu;
  do{
    printf("\n------PROGRAM----------\n");
    printf("1. \n");
    printf("2. \n");
    printf("3. \n");
    printf("4. \n");
    printf("5. \n");
    printf("6. \n");
    printf("7. \n");
    printf("8. Thoat\n");
    printf("Lua chon cua ban: " );
    scanf("%d",&menu);
  }  while(menu<0|| menu>8);
  printf("\n");
    return menu;
}
*/

//Randomize---------------------------
int randomize(){
  int i,key=0,sochuso=3;
  
  for (i=1;i<=sochuso;i++)
    key=key*10+(rand()%10);
  return key;
}




////////////FUnction with Array------------------------------
//Bubblesort--------------------------
void bubblesort(int *A,int size){
  int i,j,temp;
  int B[size]; //creat Array B to sort but A isn't changed.

  //copy A to B
  for(i=0;i<size;i++)
    *(B+i)=*(A+i);
  //sorting
  for(i=0;i<size;i++){
    for(j=i;j<size;j++){
      if(*(B+i)<*(B+j)){
        temp=*(B+i);
        *(B+i)=*(B+j);
        *(B+j)=temp;
      }
    }
  }
  //if you want sort A directly. Use:
  for(i=0;i<size;i++)
    *(A+i)=*(B+i);    
  //printf if needed.
}

//MIN MAX
int minmax(int a[], int size){
  int i,min,max;
  min=a[0];
  max=a[0];
  for(i=0;i<size;i++){
    if(a[i]<min)
      min=a[i];
    if(a[i]>max)
      max=a[i];
  }
  return max;
}

/////////Function with time------------------------------------------
//Ham tinh so phut bang gia tri gio phut thuc
int tinhtien(int gio1, int phut1, int gio2, int phut2){
  //thay vi gio12, phut12, thuong se cho struct time
  int sophut,tien;
  sophut=gio1*60+phut1 -gio2*60-phut2;

  tien=sophut*100;

  printf("So phut dung dich vu: %d\n",sophut);
  printf("So tien can tra: %d\n",tien);
  return sophut;
}


//Time compare------------------------------------
int timecompare(int gio1, int phut1, int gio2, int phut2){
  if(gio1<gio2) return -1;
  else if(gio1==gio2){
    if(phut1<phut2) return -1;
    else if(phut1==phut2) return 0;
    else return 1;
  }
  else return 1;
}

//Time vaild---------------------------------------
int timevaild(int gio, int phut){
  int ok;
  if(gio>=0 && gio<24){
    if (phut >=0 && phut<60){
      return 1;
    } else return 0;
  } else return 0;
} 
////////////////////////////////////////////////////////////

//Function with date and year///////////////////////////////
//------------------------------------------------------------------------------
int kiem_tra(int ngay, int thang, int nam) {
	if(ngay<1||ngay>31||thang<1||thang>12) return 0;
	else {
		if(thang==4||thang==6||thang==9||thang==11)	{ //thang ko co ngay 31
			if(ngay==31)return 0;
			else return 1;
		}
		else if(thang==2) {
			if(ngay>29) return 0;	//thang 2 co nhieu nhat la 29 ngay
			else if(ngay==29){
				if(nam_nhuan(nam)==1) return 1;
				else return 0;
			}
			else return 1;
			}
		else return 1;
	}
}
//------------------------------------------------------------------------------
int nam_nhuan(int nam) {
	
	if(nam%400==0) return 1;
	else {
		if(nam%100==0) return 0;
		else {
			if(nam%4==0) return 1;
			else return 0;
		}
	}
}//------------------------------------------------------------------------------
int kiem_tra(int ngay, int thang, int nam) {
	if(ngay<1||ngay>31||thang<1||thang>12) return 0;
	else {
		if(thang==4||thang==6||thang==9||thang==11)	{ //thang ko co ngay 31
			if(ngay==31)return 0;
			else return 1;
		}
		else if(thang==2) {
			if(ngay>29) return 0;	//thang 2 co nhieu nhat la 29 ngay
			else if(ngay==29){
				if(nam_nhuan(nam)==1) return 1;
				else return 0;
			}
			else return 1;
			}
		else return 1;
	}
}
//------------------------------------------------------------------------------
int nam_nhuan(int nam) {
	
	if(nam%400==0) return 1;
	else {
		if(nam%100==0) return 0;
		else {
			if(nam%4==0) return 1;
			else return 0;
		}
	}
}
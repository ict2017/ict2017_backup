#ifndef ICT58_LIBRARY
#define ICT58_LIBRARY
//Thư viện C của ICT-58
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

//Hàm flush. 
//Tác dụng: Ăn hết các ký tự, làm sạch input stream.
void flush58(); 

//menuChoice: một bộ menu được tạo sẵn
//VD: menuChoice(2,"Enter","Do Some Thing") sẽ cho ra
////////////////////
//1. Enter
//2. Do Some Thing
//0. Exit
//Your choice:
////////////////////
//Hàm return giá trị tương ứng sự lựa chọn.
int menuChoice(int numberOfOptions,...);

//Hàm shiftChar có tác dụng dịch các chữ cái trong cấu trúc ring từ a->z
//Dùng được cả với số âm và dương.
//VD: a shift 1 = b     |    A shift -1 = Z 
char shiftChar(char c,int shift);
//Bộ hàm trim của Gs Dương...
void trimString(char[]);
void trimRight(char[]);
void trimLeft(char[]);
void trimMid(char[]);
void deleteChar(char a[],int n);
//Đảo ngược array
void reverseIntArray(int *p,int size);
void reverseCharArray(char *p,int size);
//hàm sort với Int, thứ tự tăng dần thì isAcending = 1
void sortInt(int array[], int n, int isAscending);
int isValidName(char name[]);



//Các hàm tính toán:
//Change base:
void decToAny(int a,int base); //In ra số output
int anyToDec(int a,int base); //Trả về số output.




/////////////////////////////////////////////////////////////
//ICT58.C  - Phần chứa source code
/////////////////////////////////////////////////////////////
void flush58()
{
    int ch;
    while ((ch=getchar()) != '\n' && ch != EOF){}
}
int menuChoice(int numberOfOptions,...)
{
    va_list list;
    int i,choice = -1;
    va_start(list,numberOfOptions);
    printf("_____________MENU______________\n");
    for (i = 1; i <= numberOfOptions; ++i)
    {
        printf("%d. %s\n",i,va_arg(list,int*));
    }
    printf("0. Exit\n\n");
    printf("Your choice: ");
    scanf("%d",&choice);
    return choice;
}
char plusChar(char c, int shift)
{
    if (c>='a' && c<='z')
    {
        if (c>('z'-shift))
        {
            return 'a'+(shift-('z'-c));
        }
        else 
            return c+shift;
    }
    else if (c>='A' && c<='Z')
    {
        if (c>'Z'-shift)
        {
            return 'A'+(shift-('Z'-c));
        }
        else 
            return c+shift;
    }
    else return ' ';
}
char minusChar(char c, int shift)
{
    if (c>='a' && c<='z')
    {
        if (c<'a'+shift)
        {
            return 'z'-(shift-(c-'a'));
        }
        else
            return c-shift;
    }
    else if (c>='A' && c<='Z')
    {
        if (c<'A'+shift)
        {
            return 'Z'-(shift-(c-'A'));
        }
        else
            return c-shift;
    }
    else return ' ';
}
char shiftChar(char c,int shift)
{
    if(shift>0) return plusChar(c,shift);
    else return minusChar(c,shift);
}
void trimRight(char a[]){
    int i=strlen(a)-1;
    while (i>=0) {
        if (a[i]!=' ') break;
        else a[i]='\0';
        i--;
    }
}
void deleteChar(char a[],int vt){
    int i,n=strlen(a);
    for (i=vt;i<n;i++) a[i]=a[i+1];
}
void trimLeft(char a[]){
    int n=strlen(a);
    while(a[0]==' ') deleteChar(a,0);
}
void trimMid(char a[]){
    int i,k,n=strlen(a);
    for (i=0;i<n;i++){
        if (a[i]==32){
            if (a[i+1]==32){
                k=i;
                while(a[i]==32){
                    deleteChar(a,i);
                    i=k+1;
                }
            }
        }
    }
}
void trimString(char a[])
{
    trimLeft(a);
    trimMid(a);
    trimRight(a);
}
void decToAny(int a,int base) {
    int A[100], dem=0,i=0;
    do{
        A[i]=a%base;
        a/=base;
        dem++;
        i++;
    } while(a>0);
    
    for(i=dem-1;i>=0;i--){
        switch(A[i]){
            case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 0: printf("%d",A[i]); break;
            case 10: printf("A"); break;
            case 11: printf("B"); break;
            case 12: printf("C"); break;
            case 13: printf("D"); break;
            case 14: printf("E"); break;
            case 15: printf("F"); break;
        }
    }
}
int anyToDec(int a,int base){
    int dec=0,hh=1;
    do{
        dec+=(a%10)*hh;
        hh*=base;
        a/=10;
    } while (a>0);
    return (dec);
}
void reverseIntArray(int *p,int size){
    int i,temp;
    for (i=0;i<((size)/2);i++){
        temp=*(p+i);
        *(p+i)=*(p+size-1-i);
        *(p+size-1-i)=temp;
    }
}
void reverseCharArray(char *p,int size){
    int i,temp;
    for (i=0;i<((size)/2);i++){
        temp=*(p+i);
        *(p+i)=*(p+size-1-i);
        *(p+size-1-i)=temp;
    }
}
int _minMax(int a[], int size, int maxOrMin){
  int i,min,max;
  min=a[0];
  max=a[0];
  for(i=0;i<size;i++){
    if(a[i]<min)
      min=a[i];
    if(a[i]>max)
      max=a[i];
  }
  if(maxOrMin) return max;
  else return min;
}
int findMax(int a[],int size) {return _minMax(a,size,1);}
int findMin(int a[],int size) {return _minMax(a,size,0);}
void bubbleSort(int list[], int n, int (*binaryOpertor)(int,int))
{
  int c, d, t;
  for (c = 0 ; c < ( n - 1 ); c++)
  {
    for (d = 0 ; d < n - c - 1; d++)
    {
      if (binaryOpertor(list[d],list[d+1]))
      {
        t         = list[d];
        list[d]   = list[d+1];
        list[d+1] = t;
      }
    }
  }
}
int _isGreater(int a, int b){if (a>b) return 1; else return 0;}
int _isSmaller(int a, int b){if (a<b) return 1; else return 0;}
void sortInt(int array[], int n, int isAscending)
{
    if(isAscending) bubbleSort(array,n,&_isGreater);
    else bubbleSort(array,n,&_isSmaller);
}
int isCharacter(char a)
{
    a = tolower(a);
    if (a>='a' && a<='z') return 1;
    else return 0;
}
int isSpace(char a){ return (a==' ')?1:0;}
int isValidName(char name[])
{
    int i=0;
    while(name[i]!='\0')
    {
        if (!(isCharacter(name[i])||isSpace(name[i]))) return 0;
        i++;
    }
    return 1;
}
#endif
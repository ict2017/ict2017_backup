/*****************************************************************************************
 *  String Processing - Functions
 *****************************************************************************************
 * 
 * Written by DuccuongICT - HUST
 * You can distribute this file freely; however, it's only 
 * for reference, there is not any WARRANTY about the bug 
 * that may happen when you compile.
 *
 ****************************************************************************************/

#include <stdio.h>
#include <conio.h>

//---- Function Prototypes ----
int strleng(char *s);				/* Length of string s */
void strcopy(char *s, char *t);			/* Copy string t to string s */
int strcompr(char *s, char *t);			/* Compare two string s and t */
void strconcat(char *s, char *t);		/* Cpmcatemate t to the end of s */
int strend(char *s, char *t);			/* Check whether t is in the end of s */

//---- End Function Prototypes ----

/* strleng: return the length of string s, 
notice that string's length = visible characters + 1 ('\0') */
int strleng(char *s) {
    int n = 0;
    /* each character in s is examined and n is incremented by 1 until reach '\0' */ 
    while (*s++ != '\0')
	n++;
    return n;
} // test?


/* strcopy: copy string t to string s, that mean s will be equal to t */
void strcopy(char *s, char *t) {
/* ver 1: This is the fastest, nestest way */
    /* value of *t++ is character that t pointed before t was incremented;
       ++ doesn't change t until the next character after t is fetched */
    while (*s++ = *t++) 
	;

/* ver 2: using merely array 
	int = 0; 	// when compile with gcc, remember: gcc -std=c99 
	while ((s[i] = t[i]) != '\0')
	   i++;
*/

/* ver 3: using pointers
	while ((*s++ = *t++) != '\0')
	    ;
   Since '\0' marks the end of a string, it's the same for all string;
   the comparsion against '\0' is redundant -> Ver 1: the fastest way
*/
}


/* strcompr: compare the length of s and t; return 0 if s = t, a negative if s < t 
and a postive if s > t  */
int strcompr(char *s, char *t) {
    while (*s++ = *t++)
	if (*s == '\0')
	    return 0;
   return *s - *t;
}

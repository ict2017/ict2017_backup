#include <stdio.h>
#include <math.h>

int main(){
	
	int i,a,k;
	printf("nhap so a(10) can chuyen\n");
	scanf("%d",&a);
	printf("a(10)\t%d= a(2)\t",a);
	for (k=0;;k++)
		if (a<=pow(2,k)){
			for (i=k;i>=0;i--){
				if (a>=pow(2,i)){
					printf("1");
					a=a-pow(2,i);
				}
				else printf("0");
			}
			break;
		}
	printf("\n");
	return(0);
}
#include <stdio.h>
int main()
{
	int a,b,UCLN,c,BCNN,x,y,i;
	printf("Nhap 2 so a,b: \n");scanf("%d%d",&a,&b);
 
 	if (a>b)
 	{
		c=b;
		b=a;
		a=c;	
 	}
 	for(i=a;i>0;i--)
 		if(a%i==0 && b%i==0)
 		{
		printf("UCLN = %d\n",i);
 		break;
 		}
	x= a*b/i;		
	printf("BCNN = %d\n", x);
	
}
#include <stdio.h>
#include "mylib.c"
#define  NC 8
typedef struct times{
  int hour;
  int minute;
}timet;

typedef struct com_type{
  int number;
  int free;
  timet begin;
  timet end;
  long fee;
  int time_used;
}computer;

int option, b[NC];
computer a[NC];

menu(){
  printf("\nMoi ban chon 1 trong nhung lua chon sau\n");
  printf("1. Khoi tao du lieu.\n");
  printf("2. Dung may.\n");
  printf("3. Nghi choi.\n");
  printf("4. Chuyen may.\n");
  printf("5. In ra trang thai toan bo phong may.\n");
  printf("6. In ra thong thong tin phong may sap xep theo chieu giam dan ve so tien thu duoc tinh tu dau ngay.\n");
  printf("7. Goi y may dung.\n");
  printf("0. Thoat.\n");
}
void init();
void set0(timet *);
void printroom();
void printstatus(int);
void printtime(timet);
void dungmay();
int ok(int ,int );
void roimay();
int compare(timet , timet);
void sort();
void printsort();
void printhelp();
void chuyenmay();
main(){
  while(1){
    menu();
    scanf("%d",&option);
    if (option == 1) init();
    if (option == 2) dungmay();
    if (option == 3) roimay();
    if (option == 4) chuyenmay();
    if (option == 5) printroom();
    if (option == 6) printsort();
    if (option == 7) printhelp();
    if (option == 0) break;
  }
}
void set0(timet*a){
  a->hour = 0;
  a->minute = 0;
}
void printstatus(int x){
  if (x == 0) printf("buzy ");
  else printf("free ");
}
void printtime(timet x){
  printf(" ");
  if (x.hour < 10) printf("0");
  printf("%d:",x.hour);
  if (x.minute < 10) printf("0");
  printf("%d",x.minute);
  printf(" ");
}
void printroom(){
  int i;
  printf("STT Status Begin  End    Fee     Time_used\n");
  for (i = 0;i<NC;i++){
    printf("%-2d   ",i+1);
    printstatus(a[i].free);
    printtime(a[i].begin);
    printtime(a[i].end);
    printf("%5d %6d\n",a[i].fee,a[i].time_used);
  }
}
void init(){
  int i;
  for (i=0;i<NC;i++){
    a[i].free = 1;
    set0(&a[i].begin);
    set0(&a[i].end);
    a[i].fee = 0;
    a[i].time_used = 0;
  }
}
int compare(timet a,timet b ){
  if ( (b.hour-a.hour)*60+b.minute-a.minute  == 0) return(0);
  if ( (b.hour-a.hour)*60+b.minute-a.minute  > 0) return(-1);
  return(1);
}
int ok(int u, int v){
  if ((u <0)||(u>23)){
    printf("So gio phai trong khoang 0-23\n");
    return 0;
  }
  if ((v<0)||(v>59)){
    printf("So phut phai trong khoang 0-59\n");
    return 0;
  }
  return 1;
}
void dungmay(){
  int x = 0,i,u,v;
  for (i = 0;i<NC;i++)
    if (a[x].free == 1) x = 1;
  if (x == 0){
    printf("Hien khong co may nao roi.\n Moi ban quay lai sau!\n");
    return;
  }
  printf("Moi ban go so may muon dung:"); 
  while(1){
  scanf("%d",&x);
  x--;
  if ((x < 0)||(x >= NC)) 
    {
      printf("So hieu may phai lon hon 0  va nho hon %d",NC+1);
      continue;
    }
  if (a[x].free == 0){
    printf("May ban muon chon dang co nguoi dung.\n De nghi chon may khac!\n");
    continue;
  }
  printf("Nhap thoi gian bat dau choi theo dinh dang HH:MM\n");
  printf("Trong do HH la gio va MM la phut\n");
  while(1){
  scanf("%d%*c%d",&u,&v);
  if (ok(u,v)){
      a[x].free =  0;
      a[x].begin.hour = u;
      a[x].begin.minute = v;
      return;
    }
  printf("De nghi nhap lai!\n");
  }
  }
}
void roimay(){
  int x,u,v, sophut;
  printf("Nhap so may ban muon nghi choi.\n");
  while(1){
  scanf("%d",&x);
  x--;
  if (a[x].free == 1){
      printf("May dang roi. Khong co ai dung.\n");
      printf("De nghi nhap lai\n");
      continue;
    }
  break;
  }
  printf("Ghi thoi gian ket thuc theo dinh dang HH:MM\n");
  printf("Trong do HH la gio, MM la phut.\n");
  while(1){
    scanf("%d%*c%d",&u,&v);
    if (ok(u,v)){
	     a[x].end.hour =u;
	     a[x].end.minute= v;
	     if (compare(a[x].begin,a[x].end) == -1){
	       a[x].free = 1;
	       sophut = (a[x].end.hour - a[x].begin.hour)*60+
		 a[x].end.minute - a[x].begin.minute;
	       a[x].time_used = a[x].time_used + sophut; 
	       a[x].fee = 100*a[x].time_used;
	       printf("\nHOA DON THANH TOAN\n");
	         printf("Thoi gian bat dau     : "); printtime(a[x].begin);
	       printf("\nThoi gian ket thuc    : "); printtime(a[x].end);
	       printf("\nSophut dung dich vu   :  %d",sophut);
	       printf("\nSo tien phai tra      :  %dx100 = %d VND",sophut, sophut*100);
	       printf("\n-------HEN GAP LAI LAN SAU!-------\n");
	       a[x].begin.hour = 0;
	       a[x].begin.minute = 0;
	       a[x].end.hour = 0;
	       a[x].end.minute = 0;
	       return;
	     };
	     printf("Thoi gian ket thuc truoc thoi gian bat dau.\n De nghi nhap lai.\n");
	   }
	
  }
}
void sort(){
  int i,j;
  for (i = 0; i<NC;i++) b[i]= i;
  for (i=0;i<NC;i++)
    for (j=i+1;j<NC;j++)
      if (a[b[i]].fee < a[b[j]].fee)
	swap(&b[i],&b[j]);
}

void printsort(){
  int i;
  sort();
  printf("STT Status Begin  End    Fee     Time_used\n");
  for (i = 0;i<NC;i++){
    printf("%-2d   ",b[i]+1);
    printstatus(a[b[i]].free);
    printtime(a[b[i]].begin);
    printtime(a[b[i]].end);
    printf("%5d %6d\n",a[b[i]].fee,a[b[i]].time_used);
  }
}
void printhelp(){
  sort();
  printf("May ban nen  dung la may %d",b[NC-1]+1);
}
void chuyenmay(){
  int u,v;
  printf("Moi ban nhap so may dang choi va so may muon chuyen.\n");
  while(1){
    scanf("%d%d",&u,&v);
    u--; v--;
    if (a[u].free == 1){
	printf("May da nghi.\n");
	continue;}
    if (a[v].free == 0){
      printf("May muon chuyen dang co nguoi choi.\n");
      continue;
   }
    a[v].begin.hour   = a[u].begin.hour;
    a[v].begin.minute = a[u].begin.minute;
    a[u].begin.hour   = 0;
    a[u].begin.minute = 0;
    a[u].free = 1;
    a[v].free = 0;
    return;
  }
}

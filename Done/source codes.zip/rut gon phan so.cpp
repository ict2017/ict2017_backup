#include <stdio.h>

int main ()
{
	int m,n,c;
	printf("nhap phan so m/n=\n"); scanf("%d%d",&m,&n);

	
	while(m%2==0 && n%2==0)
		{
		m=m/2;
		n=n/2;
		};
	
	while(m%3==0 && n%3==0)
		{
		m=m/3;
		n=n/3;
		};

	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	
	while(m%5==0 && n%5==0)
		{
		m=m/5;
		n=n/5;
		};
	printf("m/n=%d/%d\n",m,n)	;
	
	return(0);
}
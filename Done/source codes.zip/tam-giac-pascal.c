#include <stdio.h>

int main(){
	int M[100][100],n;
	printf("In tam giac pascal, n= ");
	scanf("%d",&n);
	
	M[1][1]=1;

	printf("1\n");
	for(int i=2;i<=n;i++){
		M[i-1][0]=0; M[i-1][i]=0;	
			
		for(int j=1;j<=i;j++){
			M[i][j]= M[i-1][j-1] + M[i-1][j];
			printf("%d ",M[i][j]);
		}
		
		printf("\n");
	}
}
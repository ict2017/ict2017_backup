#include <stdio.h>

int main()

{
	int i,j,k,ngang,doc;
	printf("nhap chieu ngang="); 
	scanf("%d",&ngang);
	printf("nhap chieu rong="); 
	scanf("%d",&doc);
	
	for (i=1;i<=ngang;i++) printf("* ");printf("\n");
	
	for (j=1;j<=doc;j++)
	{
		printf("* ");
		for (k=2;k<ngang;k++) printf("  ");
		printf("*\n");
		
	}
	
	for (i=1;i<=ngang;i++) printf("* ");printf("\n");
	
	return(0);	
}

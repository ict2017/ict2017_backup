#include <stdio.h>
void swap(int *a, int *b)
{
   int temp;
 
   temp = *b;
   *b = *a;
   *a = temp;   
}
int min(int a,int b)
{
	if (a > b) return(b);
	return(a);
}
int max(int a, int b)
{
	if (b > a) return(b);
	return(a);
}

#include <stdio.h>



int minmaax(int a[], int size){
  int i,min,max;
  min=a[0];
  max=a[0];
  for(i=0;i<size;i++){
    if(a[i]<min)
      min=a[i];
    if(a[i]>max)
      max=a[i];
  }
  return max;
}

int main(){
  int i;
  int A[10]={5,6,8,2,1,9,5,4,8};
  printf("%d\n",minmaax(A,10));
}

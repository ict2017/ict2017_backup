#include <stdio.h>
int main()
{
	int n,s,a=1,b=1;
	
	do {printf("Nhap so hang thu n: "); scanf("%d", &n);} while (n<=2);
	for(int i=3;i<=n;i++)
	{
	s=a+b;
	a=b;
	b=s;
	}
	printf("%d\n",s);
}
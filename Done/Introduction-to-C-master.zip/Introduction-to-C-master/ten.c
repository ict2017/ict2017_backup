#include <stdio.h>
int main()
{
  printf("%d %d %d %d %d %d %d %d %d %d\n",'D','o','V','i','e','t','T','u','n','g');
  printf("%c%c%c%c%c%c%c%c%c%c\n",68,111,86,105,101,116,84,117,110,103);
}

#include <stdio.h>
main ()
{
  int a;
  printf("Input a: \n");
  scanf("%d",&a);
  if(a==1)
    printf("You have entered 1\n");
  else 
    printf("Another number\n");
}

#include <stdio.h>
int main(){
  float a;
  scanf("%f",&a);
  printf("%d\n",(int)a);
  return 0;
}

#include <stdio.h>
main ()
{
  char character;
  printf("Type the character: \n");
  scanf("%c",&character);
  printf("%d\n",character);
}

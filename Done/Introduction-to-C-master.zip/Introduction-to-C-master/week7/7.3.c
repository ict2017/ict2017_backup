#include <stdio.h>
main()
{
  int x;
  for(x=27;x<=100;x=x+2)
      printf("%d\n",x);
    }
}
